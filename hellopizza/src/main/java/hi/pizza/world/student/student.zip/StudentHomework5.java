package kr.ac.kopo.student;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/student/edit.do")
public class StudentHomework5 extends HttpServlet{
   {
      //오라클 JDBC 드라이버 클래스를 메모리에 로드
      try {
         Class.forName("oracle.jdbc.OracleDriver"); // jdbc 찾아 웹 앱 라이브러리 폴더에 복사 (빌드패스 필요 x 자동)
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      }//트라이캐치가 메소드 밖에 있으면 오류기에 안에 넣어줌
      
   }//생성자 말고 실행되는 초기화 블록 혹은 생성자에 넣은면 됨.
   

   String url = "jdbc:oracle:thin:@localhost:1521:xe";
   String user = "com";
   String password = "com01";

   
   @Override
   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
      req.setCharacterEncoding("UTF-8");
      String stuNo=req.getParameter("stuNo");
      String stuName=req.getParameter("stuName");
      String stuScore = req.getParameter("stuScore");
	
      int stuPoint = Integer.parseInt(req.getParameter("stuScore"));


      String sql="UPDATE student set stu_name=?, stu_score=? "+" where stu_no =?";      		
      
      try (Connection con=DriverManager.getConnection(url, user, password);
            PreparedStatement pstmt=con.prepareStatement(sql);
            ){

    	  pstmt.setString(1, stuName); 
    	  pstmt.setInt(2, stuPoint); 
    	  pstmt.setString(3, stuNo); 
         
         int num =pstmt.executeUpdate();
         System.out.println(num+"개의 레코드 변경");

      } catch (SQLException e) {
         e.printStackTrace();
      }
      
      
    resp.sendRedirect(req.getContextPath() + "/student/list.do");
      
      
   }
}