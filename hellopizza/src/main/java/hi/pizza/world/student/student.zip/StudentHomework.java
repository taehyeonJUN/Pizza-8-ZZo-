package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//1.브라우저 주소창에
//http://localhost:8000/exweb/student/list.do
//를 입력하여 접속(요청전송)하면,
//브라우저 화면에 학생목록(학번,이름)이 출력되도록 구현

//2.학생목록 화면에 "학생추가"링크를 추가하고,
//그 링크를 클릭하면,
//http://localhost:8000/exweb/student/addform.do
//로 이동하여,
//학생의 학번, 이름, 성적을 입력할 수 있는 입력엘리먼트를 출력
//(학번,이름,성적 파라미터 이름은 stuNo, stuName, stuScore로 설정

//3. 학생목록화면에서 각 학생들의 학번을 클릭하면,
//http://localhost:8000/exweb/student/editform.do
//로 이동하여,
//해당 학생의 학번, 이름, 성적을 입력할 수 있는 입력멜리먼트들을 출력
//(입력엘리먼트에는 해당 학생의 현재 학번, 이름, 성적을 출력)

@WebServlet("/student/list.do") // "/list.do" 주소로 요청이 오면 이 서블릿을 실행 //중요
public class StudentHomework extends HttpServlet{
	{
		
	try { 
		Class.forName("oracle.jdbc.OracleDriver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	}
	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	String user = "com"; //
	String password = "com01";
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {	
		
		resp.setContentType("text/html"); // 응답내용이 text/html임을 브라우저에게 알리도록 설정
		resp.setCharacterEncoding("UTF-8");  // 한글 문자열 출력
		PrintWriter out = resp.getWriter(); // 웹브라우저에 출력할 때 > 응답객체에 출력할 수 있는 스트림(파이프) 가져오기 , scanner 처럼 중요중요! 무조건 써야한다.

		out.println("<!DOCTYPE html>                    "); 
		out.println("<html>                             ");
		out.println("<head>                             ");
		out.println("<meta charset='UTF-8'>             ");
		out.println("<title>학생관리</title>   ");
		out.println("</head>                            ");
		out.println("<body>                             ");
		out.println("	<h1>학생목록</h1> ");
		out.println("<a href='" + req.getContextPath() + "/student/addform.do'>학생추가</a><br />");
		
		{
		String sql = "SELECT stu_no,stu_name, stu_score FROM student";
		
		try (
	            Connection conn= DriverManager.getConnection(url, user, password);

	            //명령문 
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            ResultSet rs = pstmt.executeQuery();
	            ) {
	         while(rs.next()) {
	        	String stu_no=rs.getString("stu_no");
	            String stu_name = rs.getString("stu_name");
	            int stu_score=rs.getInt("stu_score");
//	            out.println("br/>");
//	            out.println(stu_name+" : "+stu_no);
	           
	           out.println("<a href=" + req.getContextPath() +"/student/editform.do?stu_no="+stu_no+">"+stu_no+"</a> :"+stu_name+":" + stu_score +"<br />");
	           out.println("<a href='" + req.getContextPath() + "/student/del.do?stu_no=" + stu_no + "'><button> 삭제 </button></a><br />");
//	           out.println("<a href='" + req.getContextPath() + "/member/del.do?memId=" + memId + "'><button> 삭제 </button></a><br />");
	         }

	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
		}
		out.println("</body>                            ");
		out.println("</html>                            ");
	}
	
	
}
