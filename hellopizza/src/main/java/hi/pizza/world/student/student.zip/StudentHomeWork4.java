package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//3. 학생목록화면에서 각 학생들의 학번을 클릭하면,
//http://localhost:8000/exweb/student/editform.do
//로 이동하여,
//해당 학생의 학번, 이름, 성적을 입력할 수 있는 입력멜리먼트들을 출력
//(입력엘리먼트에는 해당 학생의 현재 학번, 이름, 성적을 출력)
@WebServlet("/student/editform.do")

public class StudentHomeWork4 extends HttpServlet {
   
   {
      //오라클 JDBC 드라이버 클래스를 메모리에 로드
      try {
         Class.forName("oracle.jdbc.OracleDriver"); // jdbc 찾아 웹 앱 라이브러리 폴더에 복사 (빌드패스 필요 x 자동)
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      }//트라이캐치가 메소드 밖에 있으면 오류기에 안에 넣어줌
   }//생성자 말고 실행되는 초기화 블록 혹은 생성자에 넣은면 됨.

   String url = "jdbc:oracle:thin:@localhost:1521:xe";
   String user = "com";
   String password = "com01";
   
   @Override
   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

      
      
      resp.setContentType("text/html");// 응답내용이 text/html임을 브라우저에 알려줌.
      resp.setCharacterEncoding("UTF-8");// 응답내용의 문자 인코딩 설정
      PrintWriter out = resp.getWriter();
      
      out .print("<!DOCTYPE html>                 ");
      out .print("<html>                          ");
      out .print("<head>                          ");
      out .print("<meta charset='UTF-8'>          ");
      out .print("<title>학생 관리</title>");
      out .print("</head>                         ");
      out .print("<body>                          ");
      out .print("   <h1>학생 정보 상세조회</h1>       ");
   
      
      String no = req.getParameter("stu_no");
//      stuNo
    
    
    
      String sql = "SELECT * FROM student where stu_no=?";

         try (Connection conn = DriverManager.getConnection(url, user, password);
               PreparedStatement pstmt = conn.prepareStatement(sql);
               ){

            pstmt.setString(1, no); //그냥 쓰면 에러(트라이 괄호안에 있으면)
            try (ResultSet rs = pstmt.executeQuery();
                  ){

               while(rs.next()) { // while 대신 if사용 가능 else는 없어도 됨.
                  String stuNo= rs.getString("stu_no");
                  String stuName= rs.getString("stu_name");
                  int stuScore=rs.getInt("stu_score");
                  
                  out .print("<div> ");
                out .print("<form action = \"" + req.getContextPath() + "/student/edit.do\" method = \"post\">");
                out .print("학번 : <input type='text' name='stuNo' value='" + stuNo + "' readonly /><br />");
                out .print("이름 : <input type='text' name='stuName'  value='" + stuName + "'/> <br />");
                out .print("성적 : <input type='text' name='stuScore' value='" + stuScore + "'/> <br />");
                out .print("<input type = 'submit' value='저장'/>");
                out .print("</form>");
                out .print("</div> ");
               }
            }    
         }catch (SQLException e) {
            e.printStackTrace();
         }

      
      
      
      out .print("</body>                         ");
      out .print("</html>                         ");
   
//                  out.println("<form action ='" + req.getContextPath() + "/student/add.do' method='post'>");
//                  out.println("학번 : <input type='text' name='stuNo'/> <br /> ");
//                  out.println("이름 : <input type='text' name='stuName'/> <br /> ");
//                  out.println("성적 : <input type='text' name='stuScore'/> <br /> ");
//                  out.println("<input type='submit' value='입력' /> ");
//                  out.println("</form>");
      
      
      
   }
   }
