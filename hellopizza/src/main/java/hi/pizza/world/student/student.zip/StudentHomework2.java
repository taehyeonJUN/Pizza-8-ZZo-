package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//2-1 저장버튼을 클릭하면
//http://localhost:8000/exweb/student/add.do
//로 이동하여, 입력한 학생 정보를 데이터베이스에 저장하고
//학생등록 화면으로 이동



@WebServlet ("/student/addform.do")//2
public class StudentHomework2 extends HttpServlet{ //1

	@Override //service + ctrl + space bar // 3
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");  
		PrintWriter out = resp.getWriter();

		out.println("<!DOCTYPE html>                    "); 
		out.println("<html>                             ");
		out.println("<head>                             ");
		out.println("<meta charset='UTF-8'>             ");
		out.println("<title>학생관리</title>   ");
		out.println("</head>                            ");
		out.println("<body>                             ");
		out.println("	<h1>학생추가</h1> ");
		
		//ContextPath : 현재 웹애플리케이션(프로젝트)의 고유 경로
		out.println("<form action ='" + req.getContextPath() + "/student/add.do' method='post'>");
		out.println("학번 : <input type='text' name='stuNo'/> <br /> ");
	    out.println("이름 : <input type='text' name='stuName'/> <br /> ");
	    out.println("성적 : <input type='text' name='stuScore'/> <br /> ");
	    out.println("<input type='submit' value='입력' /> ");
	    out.println("</form>");
		
		
		
		out.println("</body>                            ");
		out.println("</html>                            ");
	}
}
