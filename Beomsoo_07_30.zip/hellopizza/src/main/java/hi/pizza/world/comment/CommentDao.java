package hi.pizza.world.comment;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import hi.pizza.world.comm.SearchInfo;

@Mapper
public interface CommentDao 
{
	public int insertComment(CommentVo vo);
	public List<CommentVo> selectCommentList(SearchInfo searchInfo);
	int selectCount(SearchInfo searchInfo);
	
	int deleteComment(int rpId);
}
