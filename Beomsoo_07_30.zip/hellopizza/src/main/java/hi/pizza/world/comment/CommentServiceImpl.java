package hi.pizza.world.comment;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import hi.pizza.world.comm.SearchInfo;

@Service
public class CommentServiceImpl implements CommentService
{
	@Resource
	private CommentDao commentDao;
	
	@Override
	public int insertComment(CommentVo vo) 
	{
		return commentDao.insertComment(vo);
	}

	@Override
	public List<CommentVo> selectCommentList(SearchInfo searchInfo) 
	{
		return commentDao.selectCommentList(searchInfo);
	}

	@Override
	public int deleteComment(int rpId) 
	{
		return commentDao.deleteComment(rpId);
	}


	@Override
	public int selectCount(SearchInfo searchInfo) {
		return commentDao.selectCount(searchInfo);
	}


}
