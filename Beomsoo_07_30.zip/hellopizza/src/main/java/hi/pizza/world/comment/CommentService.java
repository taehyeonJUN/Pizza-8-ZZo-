package hi.pizza.world.comment;

import java.util.List;

import hi.pizza.world.comm.SearchInfo;
import hi.pizza.world.member.MemberVo;

public interface CommentService 
{
	public int insertComment(CommentVo vo);
	
	List<CommentVo> selectCommentList(SearchInfo searchInfo);
	
	int deleteComment(int rpId);
	int selectCount(SearchInfo searchInfo);
}
