package hi.pizza.world.pizzamenu;

public class PizzaMenuVo {
	private int meId;
	private String meName;
	private int mePrice;
	private String meSort;
	
	public int getMeId() {
		return meId;
	}
	public void setMeId(int meId) {
		this.meId = meId;
	}
	public String getMeName() {
		return meName;
	}
	public void setMeName(String meName) {
		this.meName = meName;
	}
	public int getMePrice() {
		return mePrice;
	}
	public void setMePrice(int mePrice) {
		this.mePrice = mePrice;
	}
	public String getMeSort() {
		return meSort;
	}
	public void setMeSort(String meSort) {
		this.meSort = meSort;
	}
	
	
	
	
	
}
