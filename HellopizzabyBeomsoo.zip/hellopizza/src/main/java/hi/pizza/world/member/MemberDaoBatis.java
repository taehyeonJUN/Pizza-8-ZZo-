package hi.pizza.world.member;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.stereotype.Repository;


import sun.security.jca.GetInstance;


//@Repository("memberDao")

public class MemberDaoBatis implements MemberDao{

//	@Resource(name = "sqlSessionFactory") // servlet-context.xml
//	private SqlSessionFactory sqlSessionFactory;
	
@Resource(name ="sqlSession")
	private SqlSession session;
	@Override
	public List<MemberVo> selectMemberList() {
		return session.selectList("hi.pizza.world.member.MemberDao.selectMemberList");
	}
	
	@Override
	public MemberVo selectMember(String memId) {
		return session.selectOne("hi.pizza.world.member.MemberDao.selectMember",memId);
	}

	@Override
	public int insertMember(MemberVo vo) {
		return session.insert("hi.pizza.world.member.MemberDao.insertMember",vo);
	 
	}

	@Override
	public int updateMember(MemberVo vo) {
		return session.update("hi.pizza.world.member.MemberDao.updateMember",vo);
		
	}

	@Override
	public int deleteMember(String memId) {
		return session.delete("hi.pizza.world.member.MemberDao.deleteMember",memId);
	}

	@Override
	   public MemberVo selectLoginMember(MemberVo memVo) {
	      return session.selectOne("hi.pizza.world.member.MemberDao.selectLoginMember",memVo);
	   }

	@Override
	public int selectCount() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
